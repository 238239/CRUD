<?php
$mysql_host = "localhost";
$mysql_database ="CRUD";
$mysql_username = "adam246";
$mysql_password = "Hello16!";
?>
