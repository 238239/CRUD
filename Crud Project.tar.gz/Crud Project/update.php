<HTML>
    <head></head>
    <body>
<?php
//update_delete.php
if ($_GET['action'] == 'Go Back') 
    {
             //action for No
        header('Location: Template.html');
        exit;   
    }
else
    {
        echo $studentID;
        echo"<HEAD> <link rel='stylesheet' href='styles.css'></HEAD>";
    
        require_once 'login.php';
        $conn = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
            if ($conn->connect_error) 
            {
             die("Connection failed: " . $conn->connect_error);
            }

	
        $sql = "SELECT * FROM Brand WHERE Name='" . $_POST['update'] . "'";
        $result = $conn->query($sql);

       $Name = $row[0];
       $Car = $row[1];
       $Age = $row[2];
        
        if ($result->num_rows > 0)//will only do this if there is something to be returned from the above line
	        {
                while($row = $result->fetch_assoc())
		            {
                        // HTML to display the form on this page.
                        echo"Edit the information for".$row['Name'].".";
	                    echo "<TABLE><TR><TH>Name</TH><TH>Car</TH><TH>Age</TH></TR>";
                        echo "<TR>";
	                    echo "<TD>".$row['Name']. "</TD><TD>". $row['Car']. "</TD><TD>". $row['Age']."</TD></TR>";
	                    echo "<form action='ChangeItem.php' method = 'post'>";
	                    echo "<TR><TD><input type='text' name = Name value=".$row['Name']." class='field left' readonly></TD>";
                        echo "<TD><input type='text' placeholder='Full Name' name='Name' class='advancedSearchTextBox'></TD>";
                        echo "<TD><select id='select' name='Car'>";
                        echo "<option value='Dodge' >Dodge</option>";
                        echo "<option value='Ford' >Ford</option>";
                        echo "<option value='Chevy' >Chevy</option>";
                        echo "<option value='Audi' >Audi</option>";
                        echo "<option value='BMW' >BMW</option>";
                        echo "<option value='Other' >Other</option>";
                        echo "</select></TD>";
                        echo "<TD><select id='select' name='year'>";
                        echo "<option value='15' >15</option>";
                        echo "<option value='16' >16</option>";
                        echo "<option value='17' >17</option>";
                        echo "<option value='18' >18</option>";
                        echo "</select></TD></TR></TABLE>";
                        echo "<input name = 'create' type = 'submit' value = 'Submit Changes'>";
                        echo "</form>";
	                    
	                    
                    } 
                 echo "</body>";   
	        }
    }
?>
</HTML>